import React, { Component } from "react";
import { StyleSheet, View, Image, TouchableOpacity } from "react-native";
import NotesImage from "../assets/notes.png";
import ChecklistImage from "../assets/checklist.png";
import CalendarImage from "../assets/calendar.png";
import SettingImage from "../assets/setting.png";

export class Nav extends Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={[styles.bar]} />
        <View style={styles.iconContainer}>
          <TouchableOpacity onPress={this.props.onNotesPress}>
            <Image source={NotesImage} style={styles.icon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={this.props.onCheckPress}>
            <Image source={ChecklistImage} style={styles.icon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={this.props.onCalendarPress}>
            <Image source={CalendarImage} style={styles.icon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={this.props.onSettingsPress}>
            <Image source={SettingImage} style={styles.icon} />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    bottom: 30,
    left: 0,
    right: 0,
    backgroundColor: "white",
  },
  iconContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    marginBottom: 10,
    marginTop: 10,
  },
  bar: {
    backgroundColor: "black",
    height: 2,
  },
  icon: {
    width: 40,
    height: 40,
  },
});

export default Nav;
