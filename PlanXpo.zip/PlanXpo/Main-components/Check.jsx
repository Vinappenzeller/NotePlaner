import React, { useState } from "react";
import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View, Button, TextInput } from "react-native";
import { addtodo } from "./components/todolist";
import { deletetodo } from "./components/delete";

import TodoEntry from "./components/TodoEntry";
let id = 1;
export default function Check() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [id, setId] = useState("");

  const buttonPress = () => {
    addtodo(title, content, setTodos, todos);
  };

  const deletePress = () => {
    let index = parseInt(id);
    deletetodo(setTodos, todos, index);
  };

  return (
    <View>
      <View>
        <View>
          <Button title="finished"></Button>
        </View>
        <View>
          <TextInput
            id="title"
            onChangeText={(value) => {
              setTitle(value);
            }}
          />
          <TextInput
            id="info"
            defaultValue="Description"
            onChangeText={(value) => setContent(value)}
          />
          <Button title="create" onPress={buttonPress}></Button>
        </View>

        <View>
          <TextInput
            id="iddelete"
            defaultValue="id"
            onChangeText={(value) => setId(value)}
          />
          <Button title="delete" onPress={deletePress}></Button>
        </View>
      </View>
      {todos.map((t) => (
        <TodoEntry title={t.title} content={t.content} id={t.id} />
      ))}
      <StatusBar style="auto" />
    </View>
  );
}
