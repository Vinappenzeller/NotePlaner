import React, { Component } from "react";
import { StyleSheet, View, Text, Image, Animated } from "react-native";
import Arrow from "../assets/arrow.png";

export class Start extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bounceValue: new Animated.Value(0),
    };
  }

  componentDidMount() {
    this.startBounceAnimation();
  }

  startBounceAnimation() {
    const { bounceValue } = this.state;
    Animated.loop(
      Animated.sequence([
        Animated.timing(bounceValue, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(bounceValue, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }

  render() {
    const { bounceValue } = this.state;

    const animatedStyle = {
      transform: [
        {
          translateY: bounceValue.interpolate({
            inputRange: [0, 1],
            outputRange: [0, 20],
          }),
        },
      ],
    };

    return (
      <View style={styles.main}>
        <Text style={styles.h1}>PlanXpo</Text>
        <Text style={styles.p}>
          Wilkommen zu PlanXpo.{"\n\n"}Hier kannst du auf deine Notizen, deine
          ToDo-List und deinen Kalender zugreifen.
        </Text>
        <View style={styles.arrowContainer}>
          <Animated.Image
            source={Arrow}
            style={[styles.arrow, animatedStyle]}
          />
        </View>
      </View>
    );
  }
}

export default Start;

const styles = StyleSheet.create({
  main: {
    marginTop: 50,
  },
  h1: {
    fontSize: 40,
    marginBottom: 20,
    marginLeft: 20,
  },
  p: {
    maxWidth: 300,
    fontSize: 20,
    marginBottom: 20,
    marginLeft: 20,
  },
  arrowContainer: {
    alignItems: "center",
  },
  arrow: {
    width: 100,
    height: 100,
    marginTop: 200,
  },
});
