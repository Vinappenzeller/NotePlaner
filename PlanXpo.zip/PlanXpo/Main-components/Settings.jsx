import React, { Component } from "react";
import { StyleSheet, View, Text, Image } from "react-native";

export class Settings extends Component {
  render() {
    return (
      <View style={styles.main}>
        <Text style={styles.h1}>Settings</Text>
      </View>
    );
  }
}

export default Settings;

const styles = StyleSheet.create({
  main: {
    marginTop: 50,
  },
  h1: {
    fontSize: 40,
    marginBottom: 20,
    marginLeft: 20,
  },
  p: {
    maxWidth: 300,
    fontSize: 20,
    marginBottom: 20,
    marginLeft: 20,
  },
});
