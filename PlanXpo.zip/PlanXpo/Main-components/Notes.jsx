import React, { useState } from "react";
import {
  View,
  Text,
  Image,
  Button,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import { TouchableWithoutFeedback } from "react-native-gesture-handler";
import DeleteIcon from "../assets/delete.png";
import { Alert } from "react-native";

export default function Notes() {
  const [notes, setNotes] = useState([]);
  const [currentNote, setCurrentNote] = useState({
    id: "",
    title: "",
    content: "",
  });
  const [showCreateNote, setShowCreateNote] = useState(false);

  const createNote = () => {
    setShowCreateNote(true);
    setCurrentNote({ id: "", title: "", content: "" });
  };

  const saveAndNavigateBack = () => {
    const existingNoteIndex = notes.findIndex(
      (note) => note.id === currentNote.id
    );

    if (existingNoteIndex !== -1) {
      const updatedNotes = [...notes];
      updatedNotes[existingNoteIndex] = currentNote;
      setNotes(updatedNotes);
    } else {
      if (
        currentNote.title.trim() !== "" ||
        currentNote.content.trim() !== ""
      ) {
        const newNote = {
          id: Date.now().toString(),
          title: currentNote.title,
          content: currentNote.content,
        };
        setNotes([...notes, newNote]);
      }
    }
    setShowCreateNote(false);
  };

  const openNote = (selectedNote) => {
    setShowCreateNote(true);
    setCurrentNote(selectedNote);
  };

  const deleteNote = (noteId) => {
    const updatedNotes = notes.filter((note) => note.id !== noteId);
    setNotes(updatedNotes);
  };

  const confirmDeleteNote = (noteId) => {
    Alert.alert(
      "Delete Note",
      "Are you sure you want to delete this note?",
      [
        {
          text: "No",
          onPress: () => console.log("Canceled deletion"),
          style: "cancel",
        },
        {
          text: "Yes",
          onPress: () => deleteNote(noteId),
        },
      ],
      { cancelable: false }
    );
  };

  return (
    <ScrollView style={styles.container} keyboardShouldPersistTaps="always">
      {!showCreateNote && (
        <View>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Notes</Text>
            <TouchableOpacity onPress={createNote}>
              <Text style={styles.addButton}>+</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.notesContainer}>
            {notes.map((note) => (
              <TouchableOpacity
                key={note.id}
                style={styles.noteButton}
                onPress={() => openNote(note)}
              >
                <Text>{note.title}</Text>
                <TouchableOpacity onPress={() => confirmDeleteNote(note.id)}>
                  <Image source={DeleteIcon} style={styles.deleteIcon} />
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}

      {showCreateNote && (
        <ScrollView>
          <View style={styles.createNoteContainer}>
            <View style={styles.saveButtonContainer}>
              <Button
                title="< Notes"
                onPress={saveAndNavigateBack}
                color="red"
              />
            </View>

            <TextInput
              style={styles.noteTitleInput}
              placeholder="Title"
              value={currentNote.title}
              onChangeText={(text) =>
                setCurrentNote({ ...currentNote, title: text })
              }
            />
            <TextInput
              style={styles.noteContentInput}
              multiline
              placeholder="Note"
              value={currentNote.content}
              onChangeText={(text) =>
                setCurrentNote({ ...currentNote, content: text })
              }
            />
          </View>
        </ScrollView>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 40,
    paddingBottom: 10,
    position: "sticky",
    top: 0,
    zIndex: 999,
    backgroundColor: "#fff",
  },
  headerTitle: {
    fontSize: 35,
    fontWeight: "bold",
    color: "red",
  },
  addButton: {
    fontSize: 35,
    fontWeight: "bold",
    color: "red",
  },
  notesContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  noteButton: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderColor: "black",
    borderWidth: 1,
    padding: 10,
    marginBottom: 10,
    borderRadius: 20,
    alignItems: "center",
    height: 60,
  },
  deleteIcon: {
    width: 30,
    height: 30,
    resizeMode: "contain",
  },

  createNoteContainer: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    flexDirection: "column",
  },
  saveButtonContainer: {
    alignSelf: "flex-start",
    marginTop: 30,
    marginLeft: -10,
  },
  noteTitleInput: {
    fontSize: 20,
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
    paddingBottom: 5,
  },
  noteContentInput: {
    fontSize: 16,
    marginBottom: 20,
    padding: 10,
    flex: 1,
  },
});
