import { View, Text, Button, StyleSheet } from 'react-native';


export async function readinfo() {
    const content = document.getElementById("info").value;
    return (
        <View>
            <Text>{content}</Text>
            <View>
                <Button style={styles.button3} title='"close'></Button>
            </View>
        </View>
    )
}
const styles = StyleSheet.create({
    container2: {
        flex: 2,
        backgroundColor: '#fff',
        alignItems: 'baseline',
    },
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    button3: {
        flex: 1 / 6,
        backgroundColor: '#fff',
        alignItems: 'flex-start',
        justifyContent: 'center',
        flexDirection: 'column',
        marginLeft: 5,
        marginRight: 5,
        marginTop: 5,
        marginBottom: 5,
    },
    button2: {
        flex: 1 / 8,
        backgroundColor: '#fff',
        alignItems: 'flex-start',
        justifyContent: 'center',
        flexDirection: 'column',
        marginLeft: 5,
        marginRight: 5,
        marginTop: 5,
        marginBottom: 5,
    },
    login: {
        flex: 1 / 6,
        backgroundColor: '#fff',
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
});
