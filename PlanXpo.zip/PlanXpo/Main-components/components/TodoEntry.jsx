import { View, Text, Button, StyleSheet } from 'react-native';
export default function TodoEntry({ title, content }) {
    return (
        <View>
            <View>

            </View>
            <Text>Title {title}</Text>
            <Text>Content: {content}</Text>
            <View>


            </View>
        </View>
    );
}


