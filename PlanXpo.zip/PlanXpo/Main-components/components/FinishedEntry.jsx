import { View, Text, Button, StyleSheet } from 'react-native';
export default function FinishedEntry({ title }) {
    return (
        <View>
            <View>

            </View>
            <Text>Title {title}</Text>

            <View>


            </View>
        </View>
    );
}
