import { View, Text, Button, StyleSheet } from 'react-native';

export async function deletetodo(setTodos, prevTodos, indexremove) {


    const neueDaten = prevTodos.filter((x, idx) => idx !== indexremove);

    setTodos(neueDaten);
};
