
export async function finishetodo(setFininshed, prevTodos, indexremove, fininsheds) {


    const neueDaten = prevTodos.filter((x, idx) => idx === indexremove);


    setFininshed([...fininsheds, neueDaten]);
};
