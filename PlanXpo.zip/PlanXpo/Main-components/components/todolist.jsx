
import { View, Text, Button, StyleSheet } from 'react-native';



let id = 0
export async function addtodo(title, content, setTodos, todos) {

    var mytodo = {
        id: id,
        date: new Date(),
        title: title,
        content: content
    }
    id += 1

    setTodos([...todos, mytodo]);


}



