import React, { Component } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
import { Calendar as CalendarComponent } from "react-native-calendars";

export class Calendar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedDate: "",
      events: {},
      eventNameInput: "",
      markedDates: {},
    };
  }

  onDayPress = (day) => {
    const selectedDate = day.dateString;
    const eventForSelectedDate = this.state.events[selectedDate];

    this.setState({ selectedDate });

    if (eventForSelectedDate) {
      Alert.alert(
        "Event",
        eventForSelectedDate[0].eventName,
        [
          {
            text: "Delete",
            onPress: () => this.deleteEvent(selectedDate),
          },
          {
            text: "Cancel",
            onPress: () => console.log("Canceled"),
            style: "cancel",
          },
        ],
        { cancelable: true }
      );
    }
  };

  addEvent = () => {
    const { selectedDate, events, eventNameInput } = this.state;

    if (!selectedDate) {
      Alert.alert("Please select a date first.");
      return;
    }

    Alert.prompt(
      "Event Name",
      "Enter the name for the event:",
      (text) => {
        const newEvent = {
          eventName: text || "New Event",
        };

        this.setState(
          (prevState) => ({
            events: {
              ...prevState.events,
              [selectedDate]: [
                newEvent,
                ...(prevState.events[selectedDate] || []),
              ],
            },
            markedDates: {
              ...prevState.markedDates,
              [selectedDate]: { selected: true, marked: true, dotColor: "red" },
            },
          }),
          () => {}
        );
      },
      undefined,
      eventNameInput
    );
  };

  deleteEvent = (selectedDate) => {
    const updatedEvents = { ...this.state.events };
    delete updatedEvents[selectedDate];

    this.setState(
      (prevState) => ({
        events: updatedEvents,
        markedDates: {
          ...prevState.markedDates,
          [selectedDate]: undefined,
        },
      }),
      () => {
        console.log("Event deleted");
      }
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Calendar App</Text>
        <CalendarComponent
          onDayPress={this.onDayPress}
          markedDates={{
            ...this.state.markedDates,
            [this.state.selectedDate]: { selected: true },
          }}
        />
        <Text style={styles.selectedDateText}>
          Selected Date: {this.state.selectedDate}
        </Text>
        <TouchableOpacity style={styles.button} onPress={this.addEvent}>
          <Text style={styles.buttonText}>Add Event</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 40,
    marginBottom: 20,
    marginLeft: 20,
  },
  selectedDateText: {
    fontSize: 18,
    marginVertical: 10,
  },
  button: {
    backgroundColor: "blue",
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
});

export default Calendar;
