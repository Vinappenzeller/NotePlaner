import React, { useState } from "react";
import { View, StyleSheet } from "react-native";
import Nav from "./Main-components/Nav.jsx";
import Start from "./Main-components/Start.jsx";
import Calendar from "./Main-components/Calendar.jsx";
import Settings from "./Main-components/Settings.jsx";
import Notes from "./Main-components/Notes.jsx";
import Check from "./Main-components/Check.jsx";
import { StatusBar } from "expo-status-bar";

export default function App() {
  const [showCalendar, setShowCalendar] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showNotes, setShowNotes] = useState(false);
  const [showCheck, setShowCheck] = useState(false);

  const renderComponent = () => {
    if (showCalendar) {
      return <Calendar />;
    } else if (showSettings) {
      return <Settings />;
    } else if (showNotes) {
      return <Notes />;
    } else if (showCheck) {
      return <Check />;
    } else {
      return <Start />;
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      {renderComponent()}
      <Nav
        onCalendarPress={() => {
          setShowCalendar(true);
          setShowSettings(false);
          setShowNotes(false);
        }}
        onSettingsPress={() => {
          setShowSettings(true);
          setShowCalendar(false);
          setShowNotes(false);
        }}
        onNotesPress={() => {
          setShowNotes(true);
          setShowCalendar(false);
          setShowSettings(false);
        }}
        onCheckPress={() => {
          setShowCheck(true);
          setShowNotes(false);
          setShowCalendar(false);
          setShowSettings(false);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: "relative",
  },
});
